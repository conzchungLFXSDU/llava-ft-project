# Intel Platforms 

* Support [Intel GPU Max Series](https://www.intel.com/content/www/us/en/products/details/discrete-gpus/data-center-gpu/max-series.html)    
* Support [Intel CPU Sapphire Rapides](https://ark.intel.com/content/www/us/en/ark/products/codename/126212/products-formerly-sapphire-rapids.html)    
* Based on [Intel Extension for Pytorch](https://intel.github.io/intel-extension-for-pytorch)    

More details in  [**intel branch**](https://github.com/haotian-liu/LLaVA/tree/intel/docs/intel)
